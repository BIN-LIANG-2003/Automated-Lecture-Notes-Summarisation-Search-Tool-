import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { GoogleLogin } from '@react-oauth/google';
import { jwtDecode } from "jwt-decode";
import UiFeedbackLayer from '../components/UiFeedbackLayer.jsx';
import AccountSelectorModal from '../components/AccountSelectorModal.jsx';
import { useUiFeedback } from '../hooks/useUiFeedback.js';
import {
  loadAccountHistory,
  removeAccountFromHistory,
  saveAccountToHistory,
} from '../lib/accountHistory.js';
import {
  getRememberAuthPreference,
  readStoredAuthSession,
  storeAuthSession,
} from '../lib/authSession.js';

export default function AuthPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [mode, setMode] = useState('login');
  const {
    toastState,
    confirmDialogState,
    showToast,
    dismissToast,
    closeConfirmDialog,
  } = useUiFeedback();
  
  const loginFormRef = useRef(null);
  const signupFormRef = useRef(null);
  const wrapperRef = useRef(null);
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [rememberSession, setRememberSession] = useState(() => getRememberAuthPreference());
  const [accountHistory, setAccountHistory] = useState(() => loadAccountHistory());
  const [showAccountSelector, setShowAccountSelector] = useState(true);
  const [signupData, setSignupData] = useState({
    username: '',
    email: '',
    password: '',
    confirm: ''
  });
  const [verificationPrompt, setVerificationPrompt] = useState(null);

  const existingSession = readStoredAuthSession();
  const existingUser = existingSession.username;
  const existingToken = existingSession.authToken;
  const postAuthRedirect = String(location.state?.from || '/').trim() || '/';

  const subtitle =
    mode === 'signup'
      ? 'Create a new account to manage your notes.'
        : existingUser && existingToken
        ? 'You are already signed in.'
        : 'Welcome back! Please sign in to continue.';
  const shouldShowAccountSelector =
    mode === 'login' &&
    showAccountSelector &&
    !existingUser &&
    !existingToken &&
    accountHistory.length > 0;

  useEffect(() => {
    document.body.classList.add('auth-light-body');
    return () => document.body.classList.remove('auth-light-body');
  }, []);

  useEffect(() => {
    if (!existingUser || !existingToken) return;
    navigate(postAuthRedirect, { replace: true });
  }, [existingToken, existingUser, navigate, postAuthRedirect]);

  useEffect(() => {
    const resize = () => {
      const active = mode === 'login' ? loginFormRef.current : signupFormRef.current;
      if (active && wrapperRef.current) {
        wrapperRef.current.style.height = `${active.scrollHeight}px`;
      }
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [mode]);

  useEffect(() => {
    const active = mode === 'login' ? loginFormRef.current : signupFormRef.current;
    active?.querySelector('input')?.focus();
  }, [mode]);

  useEffect(() => {
    if (!shouldShowAccountSelector) return;
    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        setShowAccountSelector(false);
      }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [shouldShowAccountSelector]);

  useEffect(() => {
    const prefillUsername = String(location.state?.prefillUsername || '').trim();
    const prefillEmail = String(location.state?.prefillEmail || '').trim();
    const prefillValue = prefillUsername || prefillEmail;
    if (!prefillValue) return;

    setMode('login');
    setLoginUsername(prefillValue);
    setLoginPassword('');
    setShowAccountSelector(false);

    window.requestAnimationFrame(() => {
      const passwordInput = document.getElementById('login-password');
      if (passwordInput instanceof HTMLElement) {
        passwordInput.focus();
      }
    });
  }, [location.state]);

  const rememberAccount = ({ username, email = '', avatar = '' }) => {
    const safeUsername = String(username || '').trim();
    if (!safeUsername) return;
    const next = saveAccountToHistory({
      username: safeUsername,
      email: String(email || '').trim(),
      avatar: String(avatar || '').trim(),
    });
    setAccountHistory(next);
  };

  const handleSelectAccountFromHistory = (account) => {
    const nextUsername = String(account?.username || account?.email || '').trim();
    if (!nextUsername) return;
    setMode('login');
    setLoginUsername(nextUsername);
    setLoginPassword('');
    setShowAccountSelector(false);
    window.requestAnimationFrame(() => {
      const passwordInput = document.getElementById('login-password');
      if (passwordInput instanceof HTMLElement) {
        passwordInput.focus();
      }
    });
  };

  const handleRemoveAccountFromHistory = (account) => {
    const key = String(account?.username || account?.email || '').trim();
    if (!key) return;
    const next = removeAccountFromHistory(key);
    setAccountHistory(next);
  };

  // Handle successful Google sign-in.
  const handleGoogleSuccess = async (credentialResponse) => {
    try {
      const token = credentialResponse.credential;
      const decoded = jwtDecode(token);

      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          token: token,
          email: decoded.email,
          name: decoded.name,
          remember: rememberSession,
        })
      });

      const data = await res.json();

      if (res.ok) {
        storeAuthSession({
          username: data.username,
          email: data.email || decoded.email || '',
          authToken: data.auth_token,
          remember: rememberSession,
          preferences: data.preferences || {},
        });
        rememberAccount({
          username: data.username,
          email: data.email || decoded.email || '',
          avatar: decoded.picture || '',
        });
        navigate(postAuthRedirect, { replace: true });
      } else {
        showToast(data.error || 'Google login failed', 'error');
      }
    } catch (error) {
      console.error('Google login error:', error);
      showToast('Failed to process Google login.', 'error');
    }
  };
  // ------------------------------------

  const handleLogin = async (event) => {
    event.preventDefault();
    if (!loginUsername.trim() || !loginPassword.trim()) {
      showToast('Please enter username/email and password.', 'warning');
      return;
    }

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: loginUsername.trim(),
          password: loginPassword,
          remember: rememberSession,
        })
      });

      const data = await response.json();

      if (response.ok) {
        setVerificationPrompt(null);
        storeAuthSession({
          username: data.username,
          email: data.email || (loginUsername.includes('@') ? loginUsername.trim() : ''),
          authToken: data.auth_token,
          remember: rememberSession,
          preferences: data.preferences || {},
        });
        rememberAccount({
          username: data.username,
          email: data.email || (loginUsername.includes('@') ? loginUsername.trim() : ''),
        });
        navigate(postAuthRedirect, { replace: true });
      } else {
        if (data.code === 'email_not_verified') {
          setVerificationPrompt({
            email: String(data.email || '').trim(),
            username: String(data.username || loginUsername.trim()).trim(),
            message: data.error || 'Please verify your email address before signing in.',
          });
        }
        showToast(data.error || 'Login failed', 'error');
      }
    } catch (error) {
      console.error('Login error:', error);
      showToast('Network error. Is the backend running?', 'error');
    }
  };

  const handleSignup = async (event) => {
    event.preventDefault();
    const { username, email, password, confirm } = signupData;
    
    if (!username.trim() || !email.trim() || !password || !confirm) {
      showToast('Please complete all fields.', 'warning');
      return;
    }
    if (password.length < 6) {
      showToast('Password must be at least 6 characters.', 'warning');
      return;
    }
    if (password !== confirm) {
      showToast('Passwords do not match.', 'warning');
      return;
    }

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: username.trim(),
          email: email.trim(),
          password: password
        })
      });

      const data = await response.json();

      if (response.ok) {
        setVerificationPrompt({
          email: String(data.email || email.trim()).trim(),
          username: String(data.username || username.trim()).trim(),
          message: data.message || 'Account created. Please verify your email address before signing in.',
        });
        showToast(data.message || 'Account created. Please verify your email address before signing in.', 'success');
        setMode('login');
        setLoginUsername((data.email || email.trim()).trim());
        setLoginPassword('');
        setSignupData({ username: '', email: '', password: '', confirm: '' });
      } else {
        showToast(data.error || 'Registration failed', 'error');
      }
    } catch (error) {
      console.error('Signup error:', error);
      showToast('Network error. Is the backend running?', 'error');
    }
  };

  const handleResendVerification = async () => {
    const identifier = String(
      verificationPrompt?.email || verificationPrompt?.username || loginUsername.trim()
    ).trim();
    if (!identifier) {
      showToast('Enter the account email or username first.', 'warning');
      return;
    }

    try {
      const response = await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier,
          email: verificationPrompt?.email || '',
          username: verificationPrompt?.username || '',
        }),
      });
      const data = await response.json();
      if (response.ok) {
        showToast(
          data.message || 'If the account is still awaiting verification, a new email has been sent.',
          'success',
        );
        setVerificationPrompt((prev) => (
          prev
            ? {
                ...prev,
                message: data.message || prev.message,
              }
            : prev
        ));
        return;
      }
      showToast(data.error || 'Failed to resend verification email', 'error');
    } catch (error) {
      console.error('Resend verification error:', error);
      showToast('Network error. Is the backend running?', 'error');
    }
  };

  return (
    <div className="login-body">
      <main className="login-card container" role="main">
        <AccountSelectorModal
          open={shouldShowAccountSelector}
          accounts={accountHistory}
          onSelectAccount={handleSelectAccountFromHistory}
          onRemoveAccount={handleRemoveAccountFromHistory}
          onClose={() => setShowAccountSelector(false)}
        />
        <Link to="/" className="back-home-btn" aria-label="Back to home">
          ⌂ Home
        </Link>
        <header className="auth-card-header">
          <p className="auth-kicker">StudyHub Workspace</p>
          <img src="/logo.png" alt="StudyHub Logo" className="login-logo" width="84" height="84" />
          <h1 id="auth-title">{mode === 'signup' ? 'Create account' : 'Sign in'}</h1>
          <p id="auth-subtitle" className="muted">
            {subtitle}
          </p>
        </header>

        <div id="auth-forms" className="auth-forms" aria-live="polite" ref={wrapperRef}>
          {/* Login form */}
          <form
            id="login-form"
            className={`auth-form ${mode === 'login' ? 'active' : ''}`}
            ref={loginFormRef}
            onSubmit={handleLogin}
            noValidate
          >
            <div className="auth-form-field">
              <label htmlFor="login-username">Username or email</label>
              <input
                type="text"
                id="login-username"
                placeholder="Username or email"
                required
                autoComplete="username"
                value={loginUsername}
                onChange={(event) => {
                  setLoginUsername(event.target.value);
                  if (showAccountSelector) setShowAccountSelector(false);
                }}
              />
            </div>

            <PasswordField
              id="login-password"
              label="Password"
              placeholder="Password"
              value={loginPassword}
              onChange={setLoginPassword}
              autoComplete="current-password"
            />

            <label className="auth-remember-row" htmlFor="login-remember-session">
              <input
                id="login-remember-session"
                type="checkbox"
                checked={rememberSession}
                onChange={(event) => setRememberSession(event.target.checked)}
              />
              <span>
                <strong>Keep me signed in on this device</strong>
                <small>
                  Opens email shares and workspace invitations with this account. StudyHub does not store your password.
                </small>
              </span>
            </label>

            <button type="submit" className="btn btn-primary login-btn">
              Sign in
            </button>

            <div className="auth-social">
              <div className="auth-divider" role="presentation">
                <span>OR</span>
              </div>

              <div className="auth-google-wrap">
                <GoogleLogin
                  onSuccess={handleGoogleSuccess}
                  onError={() => {
                    showToast('Google Login Failed', 'error');
                  }}
                  theme="outline"
                  shape="pill"
                  width="100%"
                />
              </div>
            </div>
            {/* ================================== */}

            <p className="auth-form-footer muted tiny">
              No account yet?{' '}
              <button type="button" id="goto-signup" className="linklike" onClick={() => setMode('signup')}>
                Create one
              </button>
              {accountHistory.length > 0 && (
                <>
                  {' '}·{' '}
                  <button
                    type="button"
                    className="linklike"
                    onClick={() => {
                      setMode('login');
                      setShowAccountSelector(true);
                    }}
                  >
                    Choose saved account
                  </button>
                </>
              )}
            </p>
            {verificationPrompt && (
              <p className="auth-form-footer muted tiny" role="status">
                {verificationPrompt.message || 'Please verify your email address before signing in.'}{' '}
                <button type="button" className="linklike" onClick={handleResendVerification}>
                  Resend verification email
                </button>
              </p>
            )}
          </form>

          {/* Sign-up form */}
          <form
            id="signup-form"
            className={`auth-form ${mode === 'signup' ? 'active' : ''}`}
            ref={signupFormRef}
            onSubmit={handleSignup}
            noValidate
          >
            <div className="auth-form-field">
              <label htmlFor="su-username">Username</label>
              <input
                type="text"
                id="su-username"
                placeholder="e.g. alice"
                required
                value={signupData.username}
                onChange={(event) => setSignupData((prev) => ({ ...prev, username: event.target.value }))}
              />
            </div>

            <div className="auth-form-field">
              <label htmlFor="su-email">Email</label>
              <input
                type="email"
                id="su-email"
                placeholder="name@example.com"
                required
                autoComplete="email"
                value={signupData.email}
                onChange={(event) => setSignupData((prev) => ({ ...prev, email: event.target.value }))}
              />
            </div>

            <PasswordField
              id="su-password"
              label="Password"
              placeholder="At least 6 characters"
              value={signupData.password}
              onChange={(value) => setSignupData((prev) => ({ ...prev, password: value }))}
              autoComplete="new-password"
            />

            <PasswordField
              id="su-password2"
              label="Confirm password"
              placeholder="Re-enter password"
              value={signupData.confirm}
              onChange={(value) => setSignupData((prev) => ({ ...prev, confirm: value }))}
              autoComplete="new-password"
              confirm
            />

            <button type="submit" className="btn btn-primary">
              Create account
            </button>
            <p className="auth-form-footer muted tiny">
              Already have an account?{' '}
              <button
                type="button"
                id="goto-login"
                className="linklike"
                onClick={() => {
                  setMode('login');
                  setLoginUsername(String(signupData.email || '').trim());
                }}
              >
                Back to sign in
              </button>
            </p>
          </form>
        </div>
      </main>
      <UiFeedbackLayer
        toastState={toastState}
        confirmDialogState={confirmDialogState}
        onDismissToast={dismissToast}
        onCloseConfirmDialog={closeConfirmDialog}
      />
    </div>
  );
}

function PasswordField({ id, label, placeholder, value, onChange, autoComplete, confirm, minLength = 6 }) {
  const [visible, setVisible] = useState(false);

  const release = () => setVisible(false);

  const handlePointerDown = (event) => {
    event.preventDefault();
    setVisible(true);
    window.addEventListener('pointerup', release, { once: true });
    window.addEventListener('pointercancel', release, { once: true });
    window.addEventListener('blur', release, { once: true });
  };

  const handleKeyDown = (event) => {
    if (event.key === ' ' || event.key === 'Enter') {
      event.preventDefault();
      setVisible(true);
    }
  };

  const handleKeyUp = (event) => {
    if (event.key === ' ' || event.key === 'Enter') {
      event.preventDefault();
      setVisible(false);
    }
  };

  return (
    <div className="auth-form-field">
      <label htmlFor={id}>{label}</label>
      <div className="field-with-toggle">
        <input
          type={visible ? 'text' : 'password'}
          id={id}
          placeholder={placeholder}
          required
          minLength={minLength}
          autoComplete={autoComplete}
          value={value}
          onChange={(event) => onChange(event.target.value)}
        />
        <button
          type="button"
          className="toggle-visibility"
          data-visible={visible ? 'true' : 'false'}
          aria-label={
            visible
              ? confirm
                ? 'Release to hide confirm password'
                : 'Release to hide password'
              : confirm
                ? 'Show confirm password'
                : 'Show password'
          }
          aria-pressed={visible ? 'true' : 'false'}
          onPointerDown={handlePointerDown}
          onKeyDown={handleKeyDown}
          onKeyUp={handleKeyUp}
          onBlur={() => setVisible(false)}
        >
          <svg className="icon-eye" viewBox="0 0 24 24">
            <path d="M12 5c-7 0-10 7-10 7s3 7 10 7 10-7 10-7-3-7-10-7Zm0 11a4 4 0 1 1 0-8 4 4 0 0 1 0 8Z" />
          </svg>
          <svg className="icon-eye-off" viewBox="0 0 24 24">
            <path d="M3 3l18 18M10.6 6.2A10.4 10.4 0 0 1 12 6c7 0 10 7 10 7a16.7 16.7 0 0 1-5.5 5.5M7.2 8.6A16.8 16.8 0 0 0 2 13s3 7 10 7c1.1 0 2.2-.2 3.2-.5" />
          </svg>
        </button>
      </div>
    </div>
  );
}
